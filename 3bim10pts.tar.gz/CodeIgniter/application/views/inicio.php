<!DOCTYPE html>
<html lang ="pt-br">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<table width="100%">
			<tr>
				<th><links onclick="chama(this)" href="http://localhost/CodeIgniter/arquivo.php">Cadastrar Nova Referência</links></th>				
			</tr>

			<tr>
				<th><a href="#">Listagem das Referências Cadastradas</a></th>				
			</tr>
			<tr>
				<th><a href="#">Consulta Referência</a></th>				
			</tr>
		</table>		
		
	</body>
</html>
