<html>

	<head>
	
		<title><?php echo $mensagem ?></title>
	</head>
	
	<body>
	
		<h1><?php echo $mensagem ?></h1>
	</body>
</html>
