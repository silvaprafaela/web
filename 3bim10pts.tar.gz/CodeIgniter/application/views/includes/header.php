<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $titulo_pagina; ?></title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
    
<body>

    
