<!DOCTYPE html>
<html lang="pt-br">
	
	<head>
		
		<meta charset="utf-8">
		<title>Meu Blog</title>
		<?php
  echo link_tag('https://fonts.googleapis.com/css?family=Roboto+Condensed');
  echo link_tag('assets/css/estilo.css');
  ?>
	</head>
	
	<body>
		
		<h3>E-mail enviado com sucesso!!</h3>
	</body>
</html>
