<!DOCTYPE HTML>
<html lang="">
<head>
    <meta charset="UTF-8">
    <title>Exemplo 2</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
    
<body>
    <h1>Exemplo 2</h1><br>
    <h3>Chamada da função incluir</h3>
    
</body>
</html>
