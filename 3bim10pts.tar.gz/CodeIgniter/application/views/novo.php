<!DOCTYPE html>
<html lang="pt-br">

	<head>
		<title>Inserir Nova Referência</title>
		<meta charset="utf-8">		
	</head>	
		
	<body>	
		<form method="post" name="formCadastro" action="" enctype="multipart/form-data">
	
		<table width="100%">
			<tr>
				<th width="15%">Nome do Arquivo:</th>
				<td width="85%"><input type="text" name="txtNome"></td>
			</tr>

			<tr>
				<th width="15%">Titulo:</th>
				<td width="85%"><input type="text" name="txtNome"></td>
			</tr>
			<tr>
				<th width="15%">Citações:</th>
				<td width="85%"><input type="text" name="txtNome"></td>
			</tr>

			<tr>
				<th width="15%">Palavras-Chave:</th>
				<td width="85%"><input type="text" name="txtNome"></td>
			</tr>

			<tr>
				<th width="15%">Referências:</th>
				<td width="85%"><input type="text" name="txtNome"></td>
			</tr>

			<input type="button" name="enviar"></td>
			</table>
		</form>
	</body>
</html>

