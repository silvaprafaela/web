<?php
require_once 'init.php';
  /*
   * função __autoload()
   * Carrega uma classe quando ela é necessária,
   * ou seja, quando é instanciada pela primeira vez.
  */
  spl_autoload_register(function ($class_name)
  {
    include '../html/'.$class_name.'.class.php';
  });

   include '../ado/TConnection.class.php';
   

  // define a consulta SQL
  $sql = "SELECT idFornecedor, nomeFornecedor, dataFundacao, email FROM fornecedores";
  try
  {
    // abre a conexão com a base BD_CEFETMG
    $conn = TConnection::open('../config/my_config.ini');
    // executa a instrução SQL
    $result = $conn->query($sql);
    
// corrigir caracteres
  $html = new TElement('html');
  $html->lang = 'pt-br';
  //instancia seção head
  $head = new TElement('head');
  $html->add($head); //adiciona ao html
  $meta = new TElement('meta');
  $meta->charset = 'utf-8';
  $head->add($meta);

  $body = new TElement('body');
  $body->bgcolor = '#DCDCDC';
  $html->add($body);
$div = new TElement('div');
$div->id='variavel';
$body->add($div);

  // *********************************************************
  //instancia objeto-tabela
  $tabela = new TTable;
  //define algumas propriedades
  $tabela->width = 600;
  $tabela->border = 1;
$div->add($tabela);
  //instancia uma linha para o cabeçalho
  $cabecalho = $tabela->addRow();
  //define a cor de fundo
  $cabecalho->bgcolor = '#3299CC';
  //adiciona células
  $cabecalho->addCell('Id Empresa');
  $cabecalho->addCell('Nome da Empresa');
  $cabecalho->addCell('Data de Fundação');
  $cabecalho->addCell('Email');


    while($row = $result->fetch(PDO::FETCH_ASSOC)) // Exibe todos os registros
    {
      
$bgcolor = '#ffffff';
    // adiciona uma linha para os dados
    $linha = $tabela->addRow();
    $linha->bgcolor = $bgcolor;
    // adiciona as células
    $linha->addCell($row['idFornecedor']);
    $linha->addCell($row["nomeFornecedor"]);
    $linha->addCell(dateConvert($row["dataFundacao"]));
    $linha->addCell($row["email"]);   
   
   

    }
$body->add($tabela);
  $html->show();
    //fecha a conexão
    $conn = null;
  } catch (Exception $e) {
    // exibe a mensagem de erro
    print "Erro! " . $e->getMessage() . "<br/>";
  }
?>
